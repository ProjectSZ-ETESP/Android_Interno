const sql = require("mysql2/promise");


const conn = sql.createPool({
    host: "localhost",
    user: "root",
    password: "12345",
    database: "bd_hospitalar",
    port: 3306
});

module.exports = conn;

