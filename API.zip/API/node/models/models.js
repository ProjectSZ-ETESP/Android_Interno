const conexao = require("./connection");
const { json } = require("express");



const getCnpjByIdFunc = async info=>{
    const comando = `SELECT * FROM tblFuncionario WHERE idUsuario LIKE ?`;
    const [resposta] = await conexao.execute(comando, info);
    return resposta;

}


const getDisponibilidadeByCnpj = async info=>{
    const comando = `SELECT * FROM tblDisponibilidade WHERE cnpj LIKE ?`;
    const [resposta] = await conexao.execute(comando,info);
    
    console.log(resposta);
    return resposta;

}

const getMedicoById = async info=>{
    const comando = `SELECT * FROM tblMedico WHERE crm LIKE ?`;
    
    const [resposta] = await conexao.execute(comando, info);
    console.log(resposta);
    return resposta;

};


const verificarLogin = async(info)=>{
    const comando = "SELECT * FROM tblUsuario WHERE email LIKE ? AND senha LIKE ?";
  //  console.log(info);
    const [reposta] = await conexao.execute(comando, info);
    return reposta;

}



const consultarHospitalCadastro = async()=>{
    const comando = "SELECT * FROM tblHospital";
    const [resposta] = await conexao.execute(comando);
    return resposta;


}



const cadastrarFuncionario2 = async(info)=>{
    const comando = `
        INSERT INTO tblUsuario(email, senha) VALUES (?, ?);
    `;
    const info1 = [
        info[0], 
        info[1]
    ];
    const [resposta] = await conexao.execute(comando, info1);
    const comando1 = "SELECT * FROM tblUsuario WHERE email LIKE ? AND senha LIKE ?";
   // console.log(info);
    let [resposta1] = await conexao.execute(comando1, info1);
   // console.log(resposta1);
    const id = resposta1[0].idUsuario;
 //   console.log(id);

    const comando2 = 'INSERT INTO tblFuncionario(cpfFuncionario, idUsuario, cnpj, nomeFuncionario) VALUES(?, ?, ?, ?);';
    const [resposta2] = await conexao.execute(comando2, [info[2], id, info[4], info[3]]);
  //  console.log("foi - inserido");


}


const getPaciente = async info=>{
    const comando = `SELECT * FROM tblPaciente WHERE idPaciente = (SELECT idPaciente FROM tblConsulta WHERE idConsulta = ?)`
    const [resposta] = await conexao.execute(comando, info);
    return resposta;

}
 

const getProntuario = async info=>{
    const comando = `SELECT * FROM tblProntuario WHERE idConsulta = ?`
    const [resposta] = await conexao.execute(comando, info);
    return resposta;



};

const getConsultasHistorico = async info=>{
    const order = (info[1]==0)?"DESC":"ASC";
    console.log(order);
    const comando = `SELECT * FROM tblConsulta WHERE idConsulta IN (SELECT idConsulta FROM tblNotificacao WHERE idUsuario LIKE ? AND tipoNotificacao LIKE 'efetuada') ORDER BY dataConsulta ${order}`;
    const [resposta] = await conexao.execute(comando, [info[0]]);
    
    return resposta;

}

const getConsultas = async info=>{
    const comando = `SELECT * FROM tblConsulta WHERE idConsulta = ?`;
    const [resposta] = await conexao.execute(comando, info);
    return resposta;
}


const getDados = async(info)=>{
    const comando = "SELECT * FROM tblFuncionario WHERE idUsuario LIKE ?";
    console.log(info);
    const [resposta] = await conexao.execute(comando, info);
    return resposta;




}



const consultarUsuarios = async ()=>{
    const comando = "SELECT * FROM tblUsuario";
    const [resposta] = await conexao.execute(comando, []);
    return resposta;
}



const funcionariosGet = async()=>{
    const comando = "SELECT * FROM tblFuncionario";
    const [resposta] = await conexao.execute(comando, []);
    return resposta;
}

const inserirFuncionario = async(info)=>{
    const comando = 'INSERT INTO tblFuncionario(cpfFuncionario, idUsuario, cnpj, nomeFuncionario) VALUES(?, ?, ?, ?);'
    const [resposta] = await conexao.execute(comando, info);
    return resposta;
};

const inserirUsuarios = async(info)=>{
    const comando = `
        INSERT INTO tblUsuario(email, senha) VALUES (?, ?);
    `;
    const [resposta] = await conexao.execute(comando, info);
    return resposta;

}

const updateUsuarios = async(info)=>{
    //console.log(info);
    const comando = `
        UPDATE tblUsuario
        SET email = ?, senha = ?
        WHERE idUsuario = ?
    `;
    //console.log("UP1");
    const [resposta] = await conexao.execute(comando, info);
    //console.log("UP");
    return resposta;
}


const atualizarFunc = async(info)=>{
    const comando = `
        UPDATE tblFuncionario
        SET nomeFuncionario = ?, cpfFuncionario = ?, cnpj = ?
        WHERE idUsuario = ?
    `;
    console.log(info);
    const [resposta] = await conexao.execute(comando, info);
    return resposta;


};

const updateSenha = async(info)=>{
    const comando = `
        UPDATE tblUsuario
        SET senha = ?
        WHERE email = ?
    `;

    const [resposta] = await conexao.execute(comando, info);
    return resposta;

}



module.exports = {
    consultarUsuarios,
    inserirUsuarios,
    updateUsuarios,
    updateSenha,
    verificarLogin,
    consultarHospitalCadastro,
    inserirFuncionario,
    funcionariosGet,
    
    cadastrarFuncionario2,
    getDados,
    atualizarFunc,
    getConsultasHistorico, 
    getProntuario,
    getPaciente,
    getConsultas,
    getMedicoById,
    getDisponibilidadeByCnpj,
    getCnpjByIdFunc


}