const express = require("express");
const app = express();
const rota = require("./rota");
const cors = require("cors");

const bodyParser = require('body-parser');

app.use(express.json());

app.use(bodyParser.raw({ limit: '50mb', type: 'application/octet-stream' }));
app.use(bodyParser.text({ type: '*/*' }));

app.use(cors());
app.use(rota);


app.listen(1234, (err)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log("running");


});

