const {Router} = require("express");
const router = Router();
const controllers = require("./controllers/controller");


router.get("/funcionario", controllers.funcionariosGet);
router.get("/usuario", controllers.consultarUsuarios);


// hospital
router.get("/getCnpjByIdFunc", controllers.getCnpjByIdFunc);
router.get("/hospital", controllers.consultarHospitalCadastro);

//login
router.get("/verificarLogin",controllers.verificarLogin);

//cadastro
router.post("/usuario", controllers.inserirUsuarios);
router.post("/inserirFuncionario", controllers.inserirFuncionario);


// Disponibilidade

router.get("/getDisponibilidadeByCnpj", controllers.getDisponibilidadeByCnpj);

// médico
router.get("/getMedicoById", controllers.getMedicoById);

// consulta
router.get("/getConsulta", controllers.getConsultas);


// prontuario
router.get("/getProntuario", controllers.getProntuario);

// Paciente
router.get("/getPaciente", controllers.getPaciente);

// historico
router.get("/getHistorioConsulta", controllers.getConsultasHistorico);


router.post("/cadastrar2", controllers.cadastrar2);


router.get("/getDados", controllers.getDados);


router.get("/atualizarFuncionario", controllers.atualizarFunc);

/***
 * 
 * 
 * get - SELECT
 * post - INSERT
 * put -  UPDATE X
 * delete - DELETE 
 * 
 * 
 * 
 * 
 * 
 * 
 */

router.get("/updateUsuario", controllers.updateUsuarios);
router.put("/usuarioSenha", controllers.updateSenha);


module.exports = router;
