const { json } = require("express");
const models  = require("../models/models");





const getCnpjByIdFunc = async(req, res)=>{
    const {idUsuario} = req.query;
    const resposta = await models.getCnpjByIdFunc([idUsuario]);
    return res.status(200).json(resposta);

}


const getDisponibilidadeByCnpj = async(req, res)=>{
    const {cnpj} = req.query;
    console.log(cnpj);
    const resposta = await models.getDisponibilidadeByCnpj([cnpj]);
    return res.status(200).json(resposta);



}

const getMedicoById = async(req, res)=>{
    const {crm} = req.query;
    console.log(crm);
    const resposta = await models.getMedicoById([crm]);
    return res.status(200).json(resposta); 


}

const getPaciente = async(req, res)=>{
    const {idPaciente} = req.query;
  //  console.log(idPaciente);
    const resposta = await models.getPaciente([idPaciente]);
    
   // console.log(resposta);
    return res.status(200).json(resposta);
}    

const getProntuario = async(req, res)=>{
    const {idConsulta} = req.query;
  //  console.log(idConsulta);
  
    const resposta = await models.getProntuario([idConsulta]);
   // console.log(resposta);
    return res.status(200).json(resposta);
    
}


const getConsultas = async(req, res)=>{
    const {idConsulta} = req.query;
    const resposta = await models.getConsultas([idConsulta]);
    return res.status(200).json(resposta);
}

const getConsultasHistorico = async(req, res)=>{
    const {idUsuario, order} = req.query;
    console.log(order);
    const resposta = await models.getConsultasHistorico([idUsuario, order]);
    console.log(resposta);
    return res.status(200).json(resposta);

}


const getDados = async(req, res)=>{
  //  console.log(req.query);
    const {idUsuario} = req.query;
 //   console.log(idUsuario);
    
    const resposta = await models.getDados([idUsuario]);
 //   console.log(resposta);
    return res.status(200).json(resposta);

}




const cadastrar2  = async(req, res)=>{
    const {email, senha,cpfFuncionario,nomeFuncionario,cnpj} = req.body;
    const resposta = await models.cadastrarFuncionario2([email, senha,cpfFuncionario,nomeFuncionario,cnpj]);
    return res.status(201).json(resposta);



}





const verificarLogin = async(req, res)=>{
    const {email, senha} = req.query;
    const resposta = await models.verificarLogin([email, senha]);
   // console.log(resposta);
    return res.status(200).json(resposta);


}

const consultarHospitalCadastro = async(req, res)=>{
    const resposta = await models.consultarHospitalCadastro();
    return res.status(200).json(resposta);

}

const funcionariosGet = async(req, res)=>{
    const resposta = await models.funcionariosGet();
    return await res.status(200).json(resposta);

}


const consultarUsuarios = async(req, res)=>{
    const resposta = await models.consultarUsuarios();
    return await res.status(200).json(resposta);


}
const inserirFuncionario = async(req, res)=>{
    const {cpfFuncionario, idUsuario, cnpj, nomeFuncionario} = req.body;
    const resposta = await models.inserirFuncionario([cpfFuncionario, idUsuario, cnpj, nomeFuncionario]);
    return await res.status(201).json(resposta);

};


const atualizarFunc = async(req, res)=>{
    const {nomeFuncionario, cpfFuncionario, cnpj, idUsuario} = req.query;

    const resposta = await models.atualizarFunc([nomeFuncionario, cpfFuncionario, cnpj, idUsuario]);
    return await res.status(202).json(resposta);
}


const inserirUsuarios = async(req, res)=>{
    const {email, senha} = req.body;
    const resposta = await models.inserirUsuarios([email, senha]);
    return await res.status(201).json(resposta);
}



const updateUsuarios = async(req, res)=>{
    const {idUsuario, email, senha} = req.query;
    const resposta = await models.updateUsuarios([email, senha, idUsuario]);
    return await res.status(200).json(resposta);
}

const updateSenha = async(req, res)=>{
    const { email, senha } = req.body;
    const resposta = await models.updateSenha([senha, email]);
    return await res.status(200).json(resposta);

    
}

module.exports = {
    consultarUsuarios,
    inserirUsuarios,
    updateUsuarios,
    updateSenha,
    verificarLogin, 
    consultarHospitalCadastro,
    inserirFuncionario,
    funcionariosGet,
    
    
    cadastrar2,
    getDados,
    atualizarFunc,
    getConsultasHistorico,
    getProntuario,
    getPaciente,
    getConsultas,
    getMedicoById,
    getDisponibilidadeByCnpj,
    getCnpjByIdFunc


}

