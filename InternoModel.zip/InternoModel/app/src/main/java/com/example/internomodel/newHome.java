package com.example.internomodel;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.internomodel.API.ApiService;
import com.example.internomodel.API.RetrofitClient;
import com.example.internomodel.API.classes.ClsFuncionario;
import com.example.internomodel.API.classes.ClsHospital;
import com.example.internomodel.API.classes.ClsLogin;
import com.example.internomodel.API.classes.ClsUsuario;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class newHome extends AppCompatActivity {

    TextView lblNomeEditPerfil, lblCPFEditPerfil, lblEmailEditPerfil, lblAssociacaoEditPerfil;
    EditText txtNomePerfil, txtCPFPerfil, txtEmailPerfil;
    Spinner spinAssociacaoPerfil;
    LinearLayout llvPopUp, llhAgendados, llhHistorico, llvAcessibilidade, llvScroll;
    View ViewPopUp;

    ApiService apiService;

    Uri imageLoad;
    String[] cnpjHospital;

    ImageView imgHome, imgSettings, imgNotification, imgPerfil, imgFichas, imgLogout, imgEdit, imgRegistros, imgClosePopUp, imgFotoPerfil;
    ClsLogin login = new ClsLogin();
    Button btnEditar, btnCancelar, btnConfirmar, btnDisponibilidade, btnEditarAgendamento;
    ConstraintLayout pg1, pg2, pg3, pg4, pg;
    ApiService apiservice;
    ActivityResultLauncher<Intent> resultLauncher;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_home);


//        Toast.makeText(getBaseContext(), login.getId(), Toast.LENGTH_SHORT).show();


        imgHome = findViewById(R.id.imgHome);
        imgSettings = findViewById(R.id.imgSettings);
        imgNotification = findViewById(R.id.imgNotifications);
        imgPerfil = findViewById(R.id.imgPerfil);

        imgEdit = findViewById(R.id.imgEdit);
        imgRegistros = findViewById(R.id.imgRegistros);
        imgLogout = findViewById(R.id.imgLogout);

        imgLogout.setOnClickListener((v) -> {
            login.setId(null);
            Intent it = new Intent(getBaseContext(), MainActivity.class);
            startActivity(it);
            finish();
        });

        imgHome.setOnClickListener((v) -> {
            moverParaTela(0);
            clearbackgrounds();
            imgHome.setBackground(getDrawable(R.drawable._semiround));
        });
        imgSettings.setOnClickListener((v) -> {
            moverParaTela(1);
            clearbackgrounds();
            imgSettings.setBackground(getDrawable(R.drawable._semiround));
        });
        imgNotification.setOnClickListener((v) -> {
            moverParaTela(2);
            clearbackgrounds();
            imgNotification.setBackground(getDrawable(R.drawable._semiround));
        });
        imgPerfil.setOnClickListener((v) -> {
            moverParaTela(3);
            clearbackgrounds();
            imgPerfil.setBackground(getDrawable(R.drawable._semiround));
        });

        pg = findViewById(R.id.paginaMaior);
        pg1 = findViewById(R.id.pagina1);
        pg2 = findViewById(R.id.pagina2);
        pg3 = findViewById(R.id.pagina3);
        pg4 = findViewById(R.id.pagina4);


        // Home


        llvPopUp = findViewById(R.id.llvPopUp);
        ViewPopUp = findViewById(R.id.ViewPopUp);
        ;
        imgClosePopUp = findViewById(R.id.imgClosePopUp);
        llhAgendados = findViewById(R.id.llhAgendados);
        llhHistorico = findViewById(R.id.llhHistorico);

        imgFichas = findViewById(R.id.imgFichas);

        btnDisponibilidade = findViewById(R.id.btnDisponibilidade);

        btnDisponibilidade.setOnClickListener(v -> {
            Intent it = new Intent(getBaseContext(), agendamento.class);
            startActivity(it);


        });

        llhAgendados.setOnClickListener((v) -> {
            Intent it = new Intent(getBaseContext(), agendamentosPendentes.class);
            startActivity(it);
        });

        llhHistorico.setOnClickListener((v) -> {
            Intent it = new Intent(getBaseContext(), HistoricoConsultas.class);
            startActivity(it);
        });


        imgFichas.setOnClickListener((v) -> {
            Intent it = new Intent(getBaseContext(), FichasMedicas.class);
            startActivity(it);
        });

        imgRegistros.setOnClickListener((v) -> {
            ViewPopUp.setVisibility(View.VISIBLE);
            llvPopUp.setVisibility(View.VISIBLE);
            ViewPopUp.setOnClickListener((vd) -> {
                closePopUp();
            });


        });

        imgClosePopUp.setOnClickListener((v) -> {
            closePopUp();
        });


        // configurações
        llvAcessibilidade = findViewById(R.id.llvAcessibilidade);
        llvAcessibilidade.setOnClickListener(v -> {
            Intent it = new Intent(getBaseContext(), Acessibilidade.class);
            startActivity(it);


        });


        // Notificações

        llvScroll = findViewById(R.id.llvScroll);

        btnEditarAgendamento = findViewById(R.id.btnEditarAgendamento);
        btnEditarAgendamento.setOnClickListener(v -> {
            Intent it = new Intent(getBaseContext(), EditarAgendamento.class);
            startActivity(it);


        });
        criarnotificacao();

        // perfil

        imgFotoPerfil = findViewById(R.id.imgFotoPerfil);

        lblNomeEditPerfil = findViewById(R.id.lblNomeEditPerfil);
        lblCPFEditPerfil = findViewById(R.id.lblCPFEditPerfil);
        lblEmailEditPerfil = findViewById(R.id.lblEmailEditPerfil);
        lblAssociacaoEditPerfil = findViewById(R.id.lblAssociacaoEditPerfil);

        txtNomePerfil = findViewById(R.id.txtNomePerfil);
        txtCPFPerfil = findViewById(R.id.txtCPFPerfil);
        txtEmailPerfil = findViewById(R.id.txtEmailPerfil);

        btnCancelar = findViewById(R.id.btnCancelar);
        btnConfirmar = findViewById(R.id.btnConfirmar);

        btnEditar = findViewById(R.id.btnEditar);

        spinAssociacaoPerfil = findViewById(R.id.spinAssociacaoPerfil);


        registerResult();
        imgEdit.setOnClickListener(v -> {

            @SuppressLint("InlinedApi") Intent it = new Intent(MediaStore.ACTION_PICK_IMAGES);
            resultLauncher.launch(it);


        });


        btnConfirmar.setOnClickListener((v) -> {


            atualizarDados();
            txtNomePerfil.setVisibility(View.GONE);
            txtEmailPerfil.setVisibility(View.GONE);
            txtCPFPerfil.setVisibility(View.GONE);
            spinAssociacaoPerfil.setVisibility(View.GONE);

            lblNomeEditPerfil.setVisibility(View.VISIBLE);
            lblCPFEditPerfil.setVisibility(View.VISIBLE);
            lblEmailEditPerfil.setVisibility(View.VISIBLE);
            lblAssociacaoEditPerfil.setVisibility(View.VISIBLE);

            lblNomeEditPerfil.setText(txtNomePerfil.getText());
            lblCPFEditPerfil.setText(txtCPFPerfil.getText());
            lblEmailEditPerfil.setText(txtEmailPerfil.getText());
            lblAssociacaoEditPerfil.setText(spinAssociacaoPerfil.getSelectedItem().toString());
            imgEdit.setVisibility(View.GONE);


            btnCancelar.setVisibility(View.GONE);
            btnConfirmar.setVisibility(View.GONE);
            btnEditar.setVisibility(View.VISIBLE);


        });

        btnCancelar.setOnClickListener((v) -> {
            txtNomePerfil.setVisibility(View.GONE);
            txtEmailPerfil.setVisibility(View.GONE);
            txtCPFPerfil.setVisibility(View.GONE);
            spinAssociacaoPerfil.setVisibility(View.GONE);

            lblNomeEditPerfil.setVisibility(View.VISIBLE);
            lblCPFEditPerfil.setVisibility(View.VISIBLE);
            lblEmailEditPerfil.setVisibility(View.VISIBLE);
            lblAssociacaoEditPerfil.setVisibility(View.VISIBLE);
            imgEdit.setVisibility(View.GONE);

            btnCancelar.setVisibility(View.GONE);
            btnConfirmar.setVisibility(View.GONE);
            btnEditar.setVisibility(View.VISIBLE);

        });


        btnEditar.setOnClickListener((v) -> {
            txtNomePerfil.setVisibility(View.VISIBLE);
            txtEmailPerfil.setVisibility(View.VISIBLE);
            txtCPFPerfil.setVisibility(View.VISIBLE);
            spinAssociacaoPerfil.setVisibility(View.VISIBLE);

          /*  txtNomePerfil.setText(lblNomeEditPerfil.getText());
            txtEmailPerfil.setText(lblEmailEditPerfil.getText());
            txtCPFPerfil.setText(lblCPFEditPerfil.getText());
*/

            lblNomeEditPerfil.setVisibility(View.GONE);
            lblCPFEditPerfil.setVisibility(View.GONE);
            lblEmailEditPerfil.setVisibility(View.GONE);
            lblAssociacaoEditPerfil.setVisibility(View.GONE);

            btnCancelar.setVisibility(View.VISIBLE);
            btnConfirmar.setVisibility(View.VISIBLE);
            btnEditar.setVisibility(View.GONE);

            imgEdit.setVisibility(View.VISIBLE);

            inicializarDados();


        });
        getHospitais();


    }

    private void moverParaTela(int tela) {
        pg1.setVisibility(View.GONE);
        pg2.setVisibility(View.GONE);
        pg3.setVisibility(View.GONE);
        pg4.setVisibility(View.GONE);

        switch (tela) {
            case 1:

                pg2.setVisibility(View.VISIBLE);
                break;
            case 2:

                pg3.setVisibility(View.VISIBLE);
                break;
            case 3:

                pg4.setVisibility(View.VISIBLE);
                break;
            default:

                pg1.setVisibility(View.VISIBLE);

                break;


        }


    }


    private void registerResult() {
        resultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult res) {
/////
                        try {

                            imageLoad = res.getData().getData();
                            imgFotoPerfil.setImageURI(imageLoad);




                        } catch (Exception err) {
                            Log.e("newHome", "ERRO: " + err);
                            Toast.makeText(getBaseContext(), "Erro!, Selecione outra imagem", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


    }


    private void clearbackgrounds() {
        imgHome.setBackground(null);
        imgPerfil.setBackground(null);
        imgNotification.setBackground(null);
        imgSettings.setBackground(null);
    }

    private void closePopUp() {
        ViewPopUp.setVisibility(View.GONE);
        llvPopUp.setVisibility(View.GONE);

    }


    private void inicializarDados() {

        apiService = RetrofitClient.getRetrofit().create(ApiService.class);
        Toast.makeText(getBaseContext(),login.getId(), Toast.LENGTH_SHORT/2).show();
        Call<List<ClsFuncionario>> call = apiService.getDados(login.getId());
        call.enqueue(new Callback<List<ClsFuncionario>>() {
            @Override
            public void onResponse(Call<List<ClsFuncionario>> call, Response<List<ClsFuncionario>> response) {

                txtNomePerfil.setText(response.body().get(0).getNomeFuncionario());
                txtCPFPerfil.setText(response.body().get(0).getCpfFuncionario());
                txtEmailPerfil.setText(login.getEmail());

                lblNomeEditPerfil.setText(response.body().get(0).getNomeFuncionario());
                lblCPFEditPerfil.setText(response.body().get(0).getCpfFuncionario());
                lblEmailEditPerfil.setText(login.getEmail());


                for (int i = 0; i < spinAssociacaoPerfil.getCount(); i++) {
                    if (cnpjHospital[i].equals(response.body().get(0).getCnpj())) {
                        spinAssociacaoPerfil.setSelection(i);
                        lblAssociacaoEditPerfil.setText(spinAssociacaoPerfil.getSelectedItem().toString());
                    }
                }

            }

            @Override
            public void onFailure(Call<List<ClsFuncionario>> call, Throwable t) {

            }
        });


    }

    private void getHospitais() {
        apiservice = RetrofitClient.getRetrofit().create(ApiService.class);
        Call<List<ClsHospital>> call = apiservice.getHospital();
        call.enqueue(new Callback<List<ClsHospital>>() {
            @Override
            public void onResponse(Call<List<ClsHospital>> call, Response<List<ClsHospital>> response) {

                String[] hospitalLista = new String[response.body().size()];
                cnpjHospital = new String[response.body().size()];
                for (int i = 0; i < response.body().size(); i++) {
                    hospitalLista[i] = response.body().get(i).getNomeHosp();
                    cnpjHospital[i] = response.body().get(i).getCnpj();
                }


                ArrayAdapter<String> adapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_spinner_item, hospitalLista);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                spinAssociacaoPerfil.setAdapter(adapter);
                inicializarDados();
            }

            @Override
            public void onFailure(Call<List<ClsHospital>> call, Throwable t) {
            }
        });
    }


    private void atualizarDados() {
        //updateUsuarios
        login.setEmail(txtEmailPerfil.getText().toString());
        apiservice = RetrofitClient.getRetrofit().create(ApiService.class);
       Call<ClsUsuario> call = apiservice.updateUsuarios(txtEmailPerfil.getText().toString(), login.getSenha(), login.getId());
        call.enqueue(new Callback<ClsUsuario>() {
            @Override
            public void onResponse(Call<ClsUsuario> call, Response<ClsUsuario> response) {

            }

            @Override
            public void onFailure(Call<ClsUsuario> call, Throwable t) {

            }
        });

        Call<ClsFuncionario> call1 = apiservice.updateFuncionarios(
                txtNomePerfil.getText().toString(),
                txtCPFPerfil.getText().toString(),
                cnpjHospital[spinAssociacaoPerfil.getSelectedItemPosition()],
                login.getId()
        );
        call1.enqueue(new Callback<ClsFuncionario>() {
            @Override
            public void onResponse(Call<ClsFuncionario> call, Response<ClsFuncionario> response) {
                Log.e("ER", "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
            }

            @Override
            public void onFailure(Call<ClsFuncionario> call, Throwable t) {

            }
        });


    }







    private void criarnotificacao(){
        LinearLayout caixa = new LinearLayout(getBaseContext());

        caixa.setBackground(getDrawable(R.drawable._border_purpleround));
        caixa.setOrientation(LinearLayout.VERTICAL);
        llvScroll.addView(caixa);

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) caixa.getLayoutParams();
        params.height = (int)(150*2.7f);
        params.width = (int)(300*2.7f);
        params.gravity = Gravity.CENTER;
        params.setMargins(0,  (int)(10*2.7f),0,0);

        caixa.setLayoutParams(params);

        LinearLayout llhHorizontal = new LinearLayout(getBaseContext());
        llhHorizontal.setOrientation(LinearLayout.HORIZONTAL);
        caixa.addView(llhHorizontal);

        params = (LinearLayout.LayoutParams) llhHorizontal.getLayoutParams();

        params.width = LinearLayout.LayoutParams.MATCH_PARENT;
        params.height = LinearLayout.LayoutParams.WRAP_CONTENT;
        params.setMargins(0, (int)(15*2.7f),0,0);
        params.weight =1;
        llhHorizontal.setLayoutParams(params);



        ImageView img = new ImageView(getBaseContext());
        img.setImageDrawable(getDrawable(R.drawable.perfildefault_icon));

        llhHorizontal.addView(img);
        params = (LinearLayout.LayoutParams) img.getLayoutParams();
        params.width = (int)(40*2.7f);
        params.height = (int)(40*2.7f);
        params.gravity = Gravity.CENTER;
        params.weight =1;


        LinearLayout llvSubVertical = new LinearLayout(getBaseContext());
        llvSubVertical.setOrientation(LinearLayout.VERTICAL);
        llhHorizontal.addView(llvSubVertical);

        params = (LinearLayout.LayoutParams) llvSubVertical.getLayoutParams();
        params.width = (int)(200*2.7);
        params.height = LinearLayout.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.CENTER;
        params.weight = 1;
        llvSubVertical.setLayoutParams(params);

        TextView lblTitle = new TextView(getBaseContext());
        TextView lblOthers = new TextView(getBaseContext());

        lblTitle.setText("TITULO");
        lblOthers.setText("EPAAAAAAAAAAAAA");
        lblTitle.setTypeface(ResourcesCompat.getFont(getBaseContext(), R.font.poppins_semibold));
        lblTitle.setGravity(Gravity.BOTTOM);
        lblTitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        lblTitle.setTextColor(getColor(R.color.black));
        lblTitle.setTextSize(15);
        llvSubVertical.addView(lblTitle);


        params =  (LinearLayout.LayoutParams) lblTitle.getLayoutParams();
        params.width = LinearLayout.LayoutParams.MATCH_PARENT;
        params.weight = LinearLayout.LayoutParams.WRAP_CONTENT;
        params.gravity = Gravity.CENTER;

        lblTitle.setLayoutParams(params);
        lblOthers.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        lblOthers.setText("Paciente: Enzo Vieira Yoshida \nDoutor: Peter Capaldi \nPara o dia 01/01/2025 às 10:00");
        lblTitle.setTypeface(ResourcesCompat.getFont(getBaseContext(), R.font.poppins_semibold));

        llvSubVertical.addView(lblOthers);
        params =  (LinearLayout.LayoutParams) lblOthers.getLayoutParams();
        params.width = LinearLayout.LayoutParams.MATCH_PARENT;
        params.height = LinearLayout.LayoutParams.MATCH_PARENT;
        params.setMargins((int)(15*2.7),0,0,0);
        lblOthers.setLayoutParams(params);

        if(("efetuada").equals("efetuada")){
            Button btnEditar = new Button(getBaseContext());
            btnEditar.setText("Editar agendamento");
            btnEditar.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            btnEditar.setGravity(Gravity.CENTER);
            btnEditar.setTextColor(getColor(R.color.white));
            btnEditar.setTextSize(15);
            btnEditar.setTypeface(ResourcesCompat.getFont(getBaseContext(), R.font.poppins_semibold));
            btnEditar.setBackground(getDrawable(R.drawable._round));

            caixa.addView(btnEditar);
            params =  (LinearLayout.LayoutParams) btnEditar.getLayoutParams();
            params.width = LinearLayout.LayoutParams.MATCH_PARENT;
            params.height = (int)(40*2.7);
            params.gravity = Gravity.CENTER;
            params.setMargins((int)(30*2.7), 0, (int)(30*2.7), (int)(2.7*10) );
            btnEditar.setLayoutParams(params);
        }








    }







}