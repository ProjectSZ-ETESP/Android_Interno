package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class MarcarAgendamento extends AppCompatActivity {

    Button btnContinuar;
    RadioButton rdoID, rdoCadastro;
    ImageView imgVoltar;
    TextView lblNomePaciente, lblCPF, lblDataNascimento, lblID;
    EditText txtNomePaciente, txtCPF, txtDataNascimento, txtID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marcar_agendamento);

        btnContinuar = findViewById(R.id.btnContinuar);

        imgVoltar = findViewById(R.id.imgVoltar);

        rdoID = findViewById(R.id.rdoID);
        rdoCadastro = findViewById(R.id.rdoCadastro);

        txtNomePaciente = findViewById(R.id.txtNomePaciente);
        txtCPF = findViewById(R.id.txtCPF);
        txtDataNascimento = findViewById(R.id.txtNascimento);
        txtID = findViewById(R.id.txtID);

        lblNomePaciente = findViewById(R.id.lblNomePaciente);
        lblCPF = findViewById(R.id.lblCPF);
        lblDataNascimento = findViewById(R.id.lblDataNascimento);
        lblID = findViewById(R.id.lblID);

        rdoID.setOnClickListener(v->{
            txtNomePaciente.setVisibility(View.GONE);
            txtCPF.setVisibility(View.GONE);
            txtDataNascimento.setVisibility(View.GONE);
            lblNomePaciente.setVisibility(View.GONE);
            lblCPF.setVisibility(View.GONE);
            lblDataNascimento.setVisibility(View.GONE);

            lblID.setVisibility(View.VISIBLE);
            txtID.setVisibility(View.VISIBLE);
        });


        rdoCadastro.setOnClickListener(v->{
            txtNomePaciente.setVisibility(View.VISIBLE);
            txtCPF.setVisibility(View.VISIBLE);
            txtDataNascimento.setVisibility(View.VISIBLE);
            lblNomePaciente.setVisibility(View.VISIBLE);
            lblCPF.setVisibility(View.VISIBLE);
            lblDataNascimento.setVisibility(View.VISIBLE);

            lblID.setVisibility(View.GONE);
            txtID.setVisibility(View.GONE);
        });

        imgVoltar.setOnClickListener(v->{
            finish();
        });

        btnContinuar.setOnClickListener(v->{
            Intent it = new Intent(getBaseContext(), confirmarAgendamento.class);
            startActivity(it);
        });


    }
}