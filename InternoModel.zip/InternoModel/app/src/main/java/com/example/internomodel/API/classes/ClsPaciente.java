package com.example.internomodel.API.classes;

import com.google.gson.annotations.SerializedName;

public class ClsPaciente {
    @SerializedName("idPaciente")
    private String idPaciente;
    @SerializedName("idUsuario")
    private String idUsuario;
    @SerializedName("cpfPaciente")
    private String cpfPaciente;
    @SerializedName("nomePaciente")
    private String nomePaciente;
    @SerializedName("sexoPaciente")
    private String sexoPaciente;
    @SerializedName("dataNascPaciente")
    private String dataNascPaciente;
    @SerializedName("tipoSanguineo")
    private String tipoSanguineo;
    @SerializedName("condicoesMedicas")
    private String condicoesMedicas;
    @SerializedName("fonePaciente")
    private String fonePaciente;
    @SerializedName("fotoPaciente")
    private String fotoPaciente;


    public ClsPaciente(String idPaciente, String idUsuario, String cpfPaciente, String nomePaciente, String sexoPaciente,
                  String dataNascPaciente, String tipoSanguineo, String condicoesMedicas, String fonePaciente, String fotoPaciente) {
        this.idPaciente = idPaciente;
        this.idUsuario = idUsuario;
        this.cpfPaciente = cpfPaciente;
        this.nomePaciente = nomePaciente;
        this.sexoPaciente = sexoPaciente;
        this.dataNascPaciente = dataNascPaciente;
        this.tipoSanguineo = tipoSanguineo;
        this.condicoesMedicas = condicoesMedicas;
        this.fonePaciente = fonePaciente;
        this.fotoPaciente = fotoPaciente;
    }

    public String getFotoPaciente() {
        return fotoPaciente;
    }

    public void setFotoPaciente(String fotoPaciente) {
        this.fotoPaciente = fotoPaciente;
    }

    public String getFonePaciente() {
        return fonePaciente;
    }

    public void setFonePaciente(String fonePaciente) {
        this.fonePaciente = fonePaciente;
    }

    public String getTipoSanguineo() {
        return tipoSanguineo;
    }

    public void setTipoSanguineo(String tipoSanguineo) {
        this.tipoSanguineo = tipoSanguineo;
    }

    public String getCondicoesMedicas() {
        return condicoesMedicas;
    }

    public void setCondicoesMedicas(String condicoesMedicas) {
        this.condicoesMedicas = condicoesMedicas;
    }

    public String getSexoPaciente() {
        return sexoPaciente;
    }

    public void setSexoPaciente(String sexoPaciente) {
        this.sexoPaciente = sexoPaciente;
    }

    public String getDataNascPaciente() {
        return dataNascPaciente;
    }

    public void setDataNascPaciente(String dataNascPaciente) {
        this.dataNascPaciente = dataNascPaciente;
    }

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public String getCpfPaciente() {
        return cpfPaciente;
    }

    public void setCpfPaciente(String cpfPaciente) {
        this.cpfPaciente = cpfPaciente;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(String idPaciente) {
        this.idPaciente = idPaciente;
    }
}
