package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class FichasMedicas extends AppCompatActivity {


    ImageView imgClose;
    LinearLayout llvNotificacoes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fichas_medicas);

        imgClose = findViewById(R.id.imgClose);

        imgClose.setOnClickListener((v)->{
            finish();
        });

        llvNotificacoes = findViewById(R.id.llvNotificacoes);

        for(int i = 0; i < llvNotificacoes.getChildCount();i++){
            LinearLayout layout = (LinearLayout) ((LinearLayout) llvNotificacoes.getChildAt(i)).getChildAt(1);
            TextView lblVerFicha = (TextView) layout.getChildAt(layout.getChildCount()-1) ;
            int a = i;
            lblVerFicha.setOnClickListener((v)->{

                Intent it = new Intent(getBaseContext(), FichaIndividual.class);
                startActivity(it);
                //Toast.makeText(getBaseContext(), " "+a, Toast.LENGTH_SHORT).show();



            });

        }





    }
}