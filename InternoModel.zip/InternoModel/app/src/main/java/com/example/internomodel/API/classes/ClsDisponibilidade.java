package com.example.internomodel.API.classes;

public class ClsDisponibilidade {
    private String idDisponibilidade;
    private String cnpj;
    private String dataIndisponivel;
    private String descricao;



    public ClsDisponibilidade(String id, String cnpj, String data, String desc){
        this.idDisponibilidade = id;
        this.cnpj = cnpj;
        this.dataIndisponivel = data;
        this.descricao = desc;

    }



    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDataIndisponivel() {
        return dataIndisponivel;
    }

    public void setDataIndisponivel(String dataIndisponivel) {
        this.dataIndisponivel = dataIndisponivel;
    }

    public String getIdDisponibilidade() {
        return idDisponibilidade;
    }

    public void setIdDisponibilidade(String idDisponibilidade) {
        this.idDisponibilidade = idDisponibilidade;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
}
