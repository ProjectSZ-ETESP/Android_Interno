package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class FichaIndividual extends AppCompatActivity {

    Spinner spinnerSangue;
    Button btnEditar, btnCancelar, btnConfirmar;

    TextView lblTipoSangue;

    LinearLayout llvCondicoes;
    ImageView imgBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_individual);

        imgBack = findViewById(R.id.imgBack);

        btnEditar = findViewById(R.id.btnEditar);
        btnCancelar = findViewById(R.id.btnCancelar);
        btnConfirmar = findViewById(R.id.btnConfirmar);

        lblTipoSangue = findViewById(R.id.lblTipoSangue);

        llvCondicoes = findViewById(R.id.llvCondicoes);

        spinnerSangue = findViewById(R.id.spinnerSangue);

        String[] tiposSanguineos = new String[]{
            "O+",
            "O-",
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tiposSanguineos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerSangue.setAdapter(adapter);

        imgBack.setOnClickListener((v)->{finish();});


        btnEditar.setOnClickListener((v)->{
            btnCancelar.setVisibility(View.VISIBLE);
            btnConfirmar.setVisibility(View.VISIBLE);
            btnEditar.setVisibility(View.GONE);

            lblTipoSangue.setVisibility(View.GONE);
            spinnerSangue.setVisibility(View.VISIBLE);

//            llvCondicoes
            for(int i = 1; i < llvCondicoes.getChildCount(); i++){
                LinearLayout layout = (LinearLayout) llvCondicoes.getChildAt(i);
                TextView label = (TextView) layout.getChildAt(0);
                EditText input = (EditText) layout.getChildAt(1);

                label.setVisibility(View.GONE);
                input.setText(label.getText());
                input.setVisibility(View.VISIBLE);
            }
        });

        btnCancelar.setOnClickListener((v)->{
            btnCancelar.setVisibility(View.GONE);
            btnConfirmar.setVisibility(View.GONE);
            btnEditar.setVisibility(View.VISIBLE);

            lblTipoSangue.setVisibility(View.VISIBLE);
            spinnerSangue.setVisibility(View.GONE);

      });


        btnConfirmar.setOnClickListener((v)->{
            btnCancelar.setVisibility(View.GONE);
            btnConfirmar.setVisibility(View.GONE);
            btnEditar.setVisibility(View.VISIBLE);

            lblTipoSangue.setText(spinnerSangue.getSelectedItem().toString());
            lblTipoSangue.setVisibility(View.VISIBLE);
            spinnerSangue.setVisibility(View.GONE);

            for(int i = 1; i < llvCondicoes.getChildCount(); i++){
                LinearLayout layout = (LinearLayout) llvCondicoes.getChildAt(i);
                TextView label = (TextView) layout.getChildAt(0);
                EditText input = (EditText) layout.getChildAt(1);

                label.setVisibility(View.VISIBLE);
                label.setText(input.getText());
                input.setVisibility(View.GONE);
            }


        });

    }
}