package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class agendamentosPendentes extends AppCompatActivity {
    ImageView imgBack,imgSetinha;
    TextView lblDataFilter;
    LinearLayout llvScroll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agendamentos_pendentes);

        llvScroll = findViewById(R.id.llvScroll);

        imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v->{finish();});

        imgSetinha = findViewById(R.id.imgSetinha);
        lblDataFilter = findViewById(R.id.lblDataFilter);

        lblDataFilter.setOnClickListener(v->{filter();});
        imgSetinha.setOnClickListener(v->{filter();});

        for(int i =0;i< llvScroll.getChildCount();i++){
            LinearLayout caixa = (LinearLayout) llvScroll.getChildAt(i);
            TextView verMais = (TextView) caixa.getChildAt(caixa.getChildCount()-1);
            verMais.setOnClickListener(v->{
                Intent it = new Intent(getBaseContext(), EditarAgendamento.class);
                startActivity(it);
            });
        }
    }

    private void filter(){
        imgSetinha.setRotation(imgSetinha.getRotation()+180);






    }
}