package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.internomodel.API.RetrofitClient;
import com.example.internomodel.API.ApiService;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.internomodel.API.ApiService;
import com.example.internomodel.API.classes.ClsLogin;
import com.example.internomodel.API.classes.ClsUsuario;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
  //  private ApiManager apiManager;


    TextView lblCriarConta;
    EditText txtSenha, txtEmail;
    ImageView imgAbrirCadastro, imgSenhaHid;
    LinearLayout llhCadastro, llvLogin;

    ConstraintLayout clLayout;

    ///
    ApiService apiservice;
    ///
    Button btnLogar;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        llhCadastro = findViewById(R.id.llhCadastro);
        lblCriarConta = findViewById(R.id.lblCriarConta);
        llvLogin = findViewById(R.id.llvLogin);
        clLayout = findViewById(R.id.clLayout);

        apiservice = RetrofitClient.getRetrofit().create(ApiService.class);

        imgAbrirCadastro = findViewById(R.id.imgAbrirCadastro);
        imgSenhaHid = findViewById(R.id.imgSenhaHid);

        txtEmail = findViewById(R.id.txtEmail);
        txtSenha = findViewById(R.id.txtSenha);

        llhCadastro.setOnClickListener((v)->{abrirCadastro();});
        lblCriarConta.setOnClickListener((v)->{abrirCadastro();});
        imgAbrirCadastro.setOnClickListener((v)->{abrirCadastro();});

        btnLogar = findViewById(R.id.btnLogar);


        imgSenhaHid.setOnClickListener((v)->{
            boolean verification = (txtSenha.getInputType() == InputType.TYPE_CLASS_TEXT);
            txtSenha.setInputType(verification?(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD):InputType.TYPE_CLASS_TEXT);
            imgSenhaHid.setImageResource(verification?R.drawable.naovisivel_icon: R.drawable.visivelolho_icon);


        });

        btnLogar.setOnClickListener((v)->{
            verificarLogin();

        });



        llvLogin.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float yInicial = 0;
                switch (event.getActionMasked()) {

                    case MotionEvent.ACTION_DOWN:
                        yInicial = event.getY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float yDesloc = event.getY() - yInicial;
                        float posicao = (llvLogin.getTranslationY() +yDesloc> llvLogin.getHeight()*0.75)?
                                llvLogin.getHeight()*0.75f
                                :
                                (llvLogin.getTranslationY() +yDesloc< 0)?0f:
                                        (llvLogin.getTranslationY()+yDesloc);

                        llvLogin.setTranslationY(posicao);
                        break;
                }
                return true;
            }
        });





    }


    private void abrirCadastro(){
        Intent it = new Intent(getBaseContext(), cadastrar.class);
        startActivity(it);
    }

    private void verificarLogin(){

        String email = txtEmail.getText().toString() , senha =  txtSenha.getText().toString();
        ClsUsuario user = new ClsUsuario(email, senha);

        Call<List<ClsUsuario>> call = apiservice.getVerificarUsuario(txtEmail.getText().toString(), txtSenha.getText().toString());

        call.enqueue(new Callback<List<ClsUsuario>>() {
            @Override
            public void onResponse(Call<List<ClsUsuario>> call1, Response<List<ClsUsuario>> response1) {
                List<ClsUsuario> a =  response1.body();

                if(a.size() == 0){
                    Toast.makeText(getBaseContext(), "Usuario não encontrado!", Toast.LENGTH_SHORT).show();
                }else{
                    ClsLogin login = new ClsLogin();

                    login.setId(a.get(0).get_idUsuario()+"");
                    login.setEmail(email);
                    login.setSenha(senha);

                    Toast.makeText(getBaseContext(), "Bem vindo(a)!", Toast.LENGTH_SHORT).show();
                    Intent it = new Intent(getBaseContext(), newHome.class);
                    startActivity(it);

                }


            }

            @Override
            public void onFailure(Call<List<ClsUsuario>> call1, Throwable t) {
                Log.e("ERRO", t.getMessage().toString());
            }
        });







    }







}