package com.example.internomodel.API;
import com.example.internomodel.API.classes.*;

import java.util.List;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("/usuario")
    Call<List<ClsUsuario>> getUsuarios();


    @GET("/verificarLogin")
    Call<List<ClsUsuario>> getVerificarUsuario(
            @Query("email") String email,
            @Query("senha") String senha);

    ///CADASTRO:

    @GET("/hospital")
    Call<List<ClsHospital>> getHospital();
    @POST("/cadastrar2")
    Call<ClsCadastrarD> cadastrar2(@Body ClsCadastrarD dados);



    // DADOS - HOME
    @GET("/getDados")
    Call<List<ClsFuncionario>> getDados(
            @Query("idUsuario") String id
    );


    @GET("/updateUsuario")
    Call<ClsUsuario> updateUsuarios(
            @Query("email") String email,
            @Query("senha") String senha,
            @Query("idUsuario") String idUsuario
    );

    @GET("/atualizarFuncionario")
    Call<ClsFuncionario> updateFuncionarios(
            @Query("nomeFuncionario") String nomeFuncionario,
            @Query("cpfFuncionario") String cpfFuncionario,
            @Query("cnpj") String cnpj,

            @Query("idUsuario") String idUsuario

    );

    @GET("/getHistorioConsulta")
    Call<List<ClsConsulta>> getHistorioConsulta(
            @Query("idUsuario") String idUsuario,
            @Query("order") String order
    );

    @GET("/getProntuario")
    Call<List<ClsProntuario>> getProntuario(
        @Query("idConsulta") String idConsulta
    );

    @GET("/getPaciente")
    Call<List<ClsPaciente>> getPaciente(
            @Query("idPaciente") String idPaciente
    );

    @GET("/getConsulta")
    Call<List<ClsConsulta>> getConsulta(
            @Query("idConsulta") String idConsulta
    );

    @GET("/getMedicoById")
    Call<List<ClsMedico>> getMedicoById(
            @Query("crm") String crm
    );

    @GET("/getDisponibilidadeByCnpj")
    Call<List<ClsDisponibilidade>> getDisponibilidadeByCnpj(
            @Query("cnpj") String cnpj
    );

    @GET("/getCnpjByIdFunc")
    Call<List<ClsFuncionario>> getCnpjByIdFunc(
            @Query("idUsuario") String idUsuario
    );
}
