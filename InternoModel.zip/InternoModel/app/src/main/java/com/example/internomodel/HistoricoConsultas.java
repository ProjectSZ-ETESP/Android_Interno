package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.internomodel.API.ApiService;
import com.example.internomodel.API.RetrofitClient;
import com.example.internomodel.API.classes.ClsConsulta;
import com.example.internomodel.API.classes.ClsLogin;
import com.example.internomodel.API.classes.ClsPaciente;
import com.example.internomodel.API.classes.ClsProntuario;

import org.w3c.dom.Text;

import java.lang.reflect.Parameter;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoricoConsultas extends AppCompatActivity {

    ImageView imgBack,imgSetinha;
    ApiService apiService;
    TextView lblDataFilter;
    LinearLayout llvScroll;
    ClsLogin login = new ClsLogin();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico_consultas);

        llvScroll = findViewById(R.id.llvScroll);


        llvScroll.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

            }
        });

        imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v->{finish();});

        imgSetinha = findViewById(R.id.imgSetinha);
        lblDataFilter = findViewById(R.id.lblDataFilter);

        lblDataFilter.setOnClickListener(v->filter());
        imgSetinha.setOnClickListener(v->filter());

        filter();
        //CriarHistoricos("0");
      //  CreateHistoryBox();

     /*   for(int i =0;i< llvScroll.getChildCount();i++){
            LinearLayout caixa = (LinearLayout) llvScroll.getChildAt(i);
            TextView verMais = (TextView) caixa.getChildAt(caixa.getChildCount()-1);
            verMais.setOnClickListener(v->{
                Intent it = new Intent(getBaseContext(), consultaEfetuada.class);
                startActivity(it);

            });


        }*/





    }




/*
*
*   <TextView
                    android:id="@+id/lblAno"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:textSize="18sp"
                    android:textColor="@color/black"
                    android:fontFamily="@font/poppins_semibold"
                    android:textAlignment="center"
                    android:layout_gravity="center"
                    android:text="2024" />
* */
@SuppressLint("ResourceAsColor")
private void criarAno(String ano){

    System.out.println("CHAMADO");
    TextView lblAno = new TextView(getBaseContext());
    lblAno.setText(ano);
    lblAno.setHeight(80);
    lblAno.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
    llvScroll.addView(lblAno);
    LinearLayout.LayoutParams lparams = (LinearLayout.LayoutParams) lblAno.getLayoutParams();
//    lparams.weight = 1;
    lblAno.setTextColor(getColor(R.color.black));
    lblAno.setTypeface(ResourcesCompat.getFont(getBaseContext(), R.font.poppins_semibold));
    lblAno.setTextSize(18);
    lparams.gravity = Gravity.CENTER;
    lblAno.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
    lblAno.setLayoutParams(lparams);
    System.out.println("CRIADO"+ano);
}


    private String tratarData(String data){
        String novaData = "";
        char chars[] = new char[10];
        for(int i = 0; i < 10; i ++){
            chars[i] = data.charAt(i);

        }
        novaData = chars[8]+""+chars[9]+"/"+chars[5]+""+chars[6];
        return novaData;
    }
    String Hnome, HdataCon, Hdesc;
    String yearr;
    private void CriarHistoricos(String order){
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        login = new ClsLogin();

        Call<List<ClsConsulta>> call = apiService.getHistorioConsulta(login.getId(), order);
        call.enqueue(new Callback<List<ClsConsulta>>() {
            @Override
            public void onResponse(Call<List<ClsConsulta>> call, Response<List<ClsConsulta>> response) {
                List<ClsConsulta> consultas = response.body();

                if (consultas.size() == 0) {
                    criarAno("Você não possui Nenhuma consulta");
                }else {

                    TextView lblAnoo = findViewById(R.id.lblAnoo);
                    yearr = getAno(consultas.get(0).getDataConsulta());

                    lblAnoo.setText(yearr);
                    for (int i = 0; i < consultas.size(); i++) {

                        ClsConsulta cons = consultas.get(i);

                        //  HdataCon = tratarData(consultas.get(i).getDataConsulta())+" - "+consultas.get(i).getHoraConsulta();
//                    Log.e("Retorno", HdataCon);


                        Call<List<ClsProntuario>> call1 = apiService.getProntuario(cons.getIdConsulta());
                        call1.enqueue(new Callback<List<ClsProntuario>>() {
                            @Override
                            public void onResponse(Call<List<ClsProntuario>> call, Response<List<ClsProntuario>> response) {
                                Log.e("Retorno", "FOIIIIIIIIIIII");

                                List<ClsProntuario> pront = response.body();
                                Log.e("prontuario ", pront.get(0).getDescricao());
                                //       Hdesc = pront.get(0).getDescricao();

                                Call<List<ClsPaciente>> call2 = apiService.getPaciente(cons.getIdPaciente());
                                call2.enqueue(new Callback<List<ClsPaciente>>() {
                                    @Override
                                    public void onResponse(Call<List<ClsPaciente>> call, Response<List<ClsPaciente>> response) {
                                        ClsPaciente paciente = response.body().get(0);
                                        Log.e("Nome: ", paciente.getNomePaciente());
                                        Hnome = paciente.getNomePaciente();
                                        HdataCon = tratarData(cons.getDataConsulta()) + " - " + cons.getHoraConsulta();
                                        Hdesc = pront.get(0).getDescricao();


                                        String y = getAno(cons.getDataConsulta());


                                        if (!y.equals(yearr)) {
                                            yearr = y;
                                            criarAno(yearr);
                                        }

                                        CreateHistoryBox(HdataCon, Hnome, Hdesc, cons.getIdConsulta());


                                    }

                                    @Override
                                    public void onFailure(Call<List<ClsPaciente>> call, Throwable t) {

                                    }
                                });


                            }

                            @Override
                            public void onFailure(Call<List<ClsProntuario>> call, Throwable t) {
                                Log.e("Retorno", "ERRO " + t);

                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(Call<List<ClsConsulta>> call, Throwable t) {

            }
        });

    }

    private String getAno(String data){
        String ano = "";
        for(int i = 0; i < 4;i++){
            ano += data.charAt(i);

        }
        return ano;
    }
    private void ClearHistoryBox(){

        while(llvScroll.getChildCount() > 0){
            llvScroll.removeView(llvScroll.getChildAt(0));
        }
       // criarAno("OI");

    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void CreateHistoryBox(String Sdata, String Spaciente, String Descricao, String idConsulta){

        LinearLayout historyBox = new LinearLayout(this);

        TextView data = new TextView(this);
        TextView paciente = new TextView(this);
        TextView descricao = new TextView(this);
        TextView desc = new TextView(this);
        TextView verMais = new TextView(this);

        String dataS = "Data: "+Sdata,
                pacienteS = "Nome: "+Spaciente,
                descricaoS = "Descrição:",
                descS = Descricao;

        TextView[] Texts = {
                data,
                paciente,
                descricao,
                desc
        };


        verMais.setText("Ver mais...");



        data.setText(dataS);
        paciente.setText(pacienteS);
        descricao.setText(descricaoS);
        desc.setText(descS);

        llvScroll.addView(historyBox);

        historyBox.setOrientation(LinearLayout.VERTICAL);
        historyBox.setBackground(getDrawable(R.drawable._dialogbox));

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) historyBox.getLayoutParams();
        params.setMargins(0,30,0,0);
        params.height = 825;

        historyBox.setLayoutParams(params);



        for (int i = 0; i < Texts.length; i++) {
            TextView e = Texts[i];
            historyBox.addView(e);
            LinearLayout.LayoutParams lparams = (LinearLayout.LayoutParams) e.getLayoutParams();
            lparams.setMargins(0,25,0,0);

            lparams.height = LinearLayout.LayoutParams.WRAP_CONTENT;
            e.setLayoutParams(lparams);
            e.setPadding(25,0,0,0);
            e.setTextSize(15);
            e.setTypeface(ResourcesCompat.getFont(getBaseContext(), R.font.poppins_medium));
            e.setTextColor(getColor(R.color.white));
            e.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);

        }
        desc.setHeight(440);

        historyBox.addView(verMais);


        verMais.setTextColor(getColor(R.color.white));
        verMais.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        verMais.setTypeface(ResourcesCompat.getFont(getBaseContext(), R.font.poppins_semibold));
        verMais.setGravity(View.TEXT_ALIGNMENT_CENTER);
        LinearLayout.LayoutParams lparams = (LinearLayout.LayoutParams) verMais.getLayoutParams();
        lparams.gravity = Gravity.CENTER;
        lparams.height = LinearLayout.LayoutParams.MATCH_PARENT;
        verMais.setLayoutParams(lparams);


        for(int i =0;i< llvScroll.getChildCount();i++) {
            try {
                LinearLayout caixa = (LinearLayout) llvScroll.getChildAt(i);
                TextView lblVerMais = (TextView) caixa.getChildAt(caixa.getChildCount() - 1);
                if(!lblVerMais.hasOnClickListeners()) {
                    lblVerMais.setOnClickListener(v -> {
                        login.setIdConsultaForH(idConsulta);
                        Intent it = new Intent(getBaseContext(), consultaEfetuada.class);
                        startActivity(it);
//idConsulta
                    });
                }
            }catch(Exception err){
                Log.e("Erro ",err.toString());
            }
        }

    }

    private void filter(){
        ClearHistoryBox();
        imgSetinha.setRotation(imgSetinha.getRotation()+180);
       // Log.e("ROT",(int)imgSetinha.getRotation()/180%2+"");
        CriarHistoricos(((int)imgSetinha.getRotation()/180%2==0)?"0":"1");

    }

}