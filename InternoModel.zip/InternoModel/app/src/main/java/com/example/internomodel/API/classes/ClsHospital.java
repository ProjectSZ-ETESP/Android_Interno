package com.example.internomodel.API.classes;

import com.google.gson.annotations.SerializedName;

public class ClsHospital {

/*
cnpj char(14) PRIMARY KEY,
nomeHosp varchar(50) NOT NULL,
direcao varchar(50) NOT NULL,
descricaoHosp varchar(100) NOT NULL,
emailHosp varchar(50) NOT NULL,
endereco varchar(100) NOT NULL,
horarioHosp varchar(50),
foneHosp char(11)

* */


    public ClsHospital(String cnpj,String nomeHosp,String direcao,String descricaoHosp,String emailHosp,String endereco,String horarioHosp,String foneHosp){
        this.cnpj = cnpj;
        this.nomeHosp = nomeHosp;
        this.direcao = direcao;
        this.descricaoHosp = descricaoHosp;
        this.emailHosp = emailHosp;
        this.endereco = endereco;
        this.horarioHosp = horarioHosp;
        this.foneHosp = foneHosp;
    }


    @SerializedName("cnpj")
    private String cnpj;

    @SerializedName("nomeHosp")
    private String nomeHosp;

    @SerializedName("direcao")
    private String direcao;

    @SerializedName("descricaoHosp")
    private String descricaoHosp;

    @SerializedName("emailHosp")
    private String emailHosp;

    @SerializedName("endereco")
    private String endereco;

    @SerializedName("horarioHosp")
    private String horarioHosp;

    @SerializedName("foneHosp")
    private String foneHosp;









    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNomeHosp() {
        return nomeHosp;
    }

    public void setNomeHosp(String nomeHosp) {
        this.nomeHosp = nomeHosp;
    }

    public String getDirecao() {
        return direcao;
    }

    public void setDirecao(String direcao) {
        this.direcao = direcao;
    }

    public String getDescricaoHosp() {
        return descricaoHosp;
    }

    public void setDescricaoHosp(String descricaoHosp) {
        this.descricaoHosp = descricaoHosp;
    }

    public String getEmailHosp() {
        return emailHosp;
    }

    public void setEmailHosp(String emailHosp) {
        this.emailHosp = emailHosp;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getHorarioHosp() {
        return horarioHosp;
    }

    public void setHorarioHosp(String horarioHosp) {
        this.horarioHosp = horarioHosp;
    }

    public String getFoneHosp() {
        return foneHosp;
    }

    public void setFoneHosp(String foneHosp) {
        this.foneHosp = foneHosp;
    }
}
