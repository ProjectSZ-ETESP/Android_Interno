package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class Acessibilidade extends AppCompatActivity {

    ImageView imgVoltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acessibilidade);

        imgVoltar = findViewById(R.id.imgVoltar);
        imgVoltar.setOnClickListener(v->{finish();});

    }
}