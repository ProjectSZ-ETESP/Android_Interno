package com.example.internomodel.API.classes;
import com.google.gson.annotations.SerializedName;

public class ClsFuncionario {

    @SerializedName("idUsuario")
    private String idUsuario;
    @SerializedName("cpfFuncionario")
    private String cpfFuncionario;
    @SerializedName("nomeFuncionario")
    private String nomeFuncionario;
    @SerializedName("cnpj")
    private String cnpj;


    public ClsFuncionario(String idUsuario, String cpfFuncionario, String nomeFuncionario, String cnpj){
        this.idUsuario = idUsuario;
        this.cpfFuncionario = cpfFuncionario;
        this.nomeFuncionario = nomeFuncionario;
        this.cnpj = cnpj;
    }








    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public String getCpfFuncionario() {
        return cpfFuncionario;
    }

    public void setCpfFuncionario(String cpfFuncionario) {
        this.cpfFuncionario = cpfFuncionario;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }





/*
*
*
*
* cpfFuncionario
* idUsuario,
* cnpj,
* nomeFuncionario
*
*
*
* cpfFuncionario char(11) PRIMARY KEY,
idUsuario int,
cnpj char(14),
nomeFuncionario varchar(50) NOT NULL,
sexoFuncionario char(1) NOT NULL,
foneFuncionario char(11),
fotoFuncionario varbinary(64000),

*
* */





}
