package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class EditarAgendamento extends AppCompatActivity {

    ImageView imgBack, imgClosePopUp;
    Button btnCancelar, btnConfirmarPopUp, btnCancelarPopUp;
    View viewPopUp;
    LinearLayout llvPopUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_agendamento);
        imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v->{finish();});
        viewPopUp = findViewById(R.id.viewPopUp);

        llvPopUp = findViewById(R.id.llvPopUp);

        btnCancelar = findViewById(R.id.btnCancelar);
        btnConfirmarPopUp = findViewById(R.id.btnConfirmarPopUp);
        btnCancelarPopUp = findViewById(R.id.btnCancelarPopUp);

        imgClosePopUp = findViewById(R.id.imgClosePopUp);




        btnCancelar.setOnClickListener(v->{
            viewPopUp.setVisibility(View.VISIBLE);
            llvPopUp.setVisibility(View.VISIBLE);
        });

        viewPopUp.setOnClickListener(v->{closePopUp();});
        btnCancelarPopUp.setOnClickListener(v->{closePopUp();});
        imgClosePopUp.setOnClickListener(v->{closePopUp();});
        btnConfirmarPopUp.setOnClickListener(v->{
            closePopUp();
            Toast.makeText(getBaseContext(), "Consulta cancelada!", Toast.LENGTH_SHORT).show();
        });


    }


    private void closePopUp(){
        viewPopUp.setVisibility(View.GONE);
        llvPopUp.setVisibility(View.GONE);



    }

}