package com.example.internomodel.API.classes;

import com.google.gson.annotations.SerializedName;

public class ClsConsulta {
    @SerializedName("idConsulta")
    private String idConsulta;
    @SerializedName("cnpj")
    private String cnpj;
    @SerializedName("crm")
    private String crm;
    @SerializedName("idPaciente")
    private String idPaciente;
    @SerializedName("dataConsulta")
    private String dataConsulta;
    @SerializedName("horaConsulta")
    private String horaConsulta;
    @SerializedName("tipoConsulta")
    private String tipoConsulta;


    public ClsConsulta(String id, String cnpj, String crm, String idPaci, String dataCon, String horaCon, String preCon){
        this.idConsulta = id;
        this.cnpj = cnpj;
        this.crm = crm;
        this.idPaciente = idPaci;
        this.dataConsulta = dataCon;
        this.horaConsulta = horaCon;
        this.tipoConsulta = preCon;


    }



    public String getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(String idConsulta) {
        this.idConsulta = idConsulta;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(String idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getDataConsulta() {
        return dataConsulta;
    }

    public void setDataConsulta(String dataConsulta) {
        this.dataConsulta = dataConsulta;
    }

    public String getHoraConsulta() {
        return horaConsulta;
    }

    public void setHoraConsulta(String horaConsulta) {
        this.horaConsulta = horaConsulta;
    }

    public String getTipoConsulta() {
        return tipoConsulta;
    }

    public void setTipoConsulta(String preConsulta) {
        this.tipoConsulta = preConsulta;
    }
}
