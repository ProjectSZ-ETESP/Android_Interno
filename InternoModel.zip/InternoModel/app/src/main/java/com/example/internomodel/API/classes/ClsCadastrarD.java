package com.example.internomodel.API.classes;

import com.google.gson.annotations.SerializedName;

public class ClsCadastrarD {

    @SerializedName("nomeFuncionario")
    private String nomeFuncionario;
    @SerializedName("cnpj")
    private String cnpj;
    @SerializedName("cpfFuncionario")
    private String cpfFuncionario;

    @SerializedName("email")
    private String email;
    @SerializedName("senha")
    private String senha;



    public ClsCadastrarD(String em, String se, String no, String cp, String cn){
        this.email = em;
        this.senha = se;
        this.nomeFuncionario = no;
        this.cpfFuncionario = cp;
        this.cnpj = cn;

    }







    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCpfFuncionario() {
        return cpfFuncionario;
    }

    public void setCpfFuncionario(String cpfFuncionario) {
        this.cpfFuncionario = cpfFuncionario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
