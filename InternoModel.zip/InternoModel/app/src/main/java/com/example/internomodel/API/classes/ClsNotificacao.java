package com.example.internomodel.API.classes;

public class ClsNotificacao {
    private String idNotificacao;
    private String idUsuario;
    private String cnpj ;
    private String idConsulta;
    private String tipoNotificacao;
    private String textoNotificacao;
    private String dataCriacao;
    private String horaCriacao;
    private String lida;

    public ClsNotificacao(String idNot, String idUsuario, String cnpj,
                          String idConsulta,String tipoNot, String txtNot, String dataCri,
                          String dataHor, String lida){
        this.idNotificacao = idNot;
        this.idUsuario = idUsuario;
        this.cnpj = cnpj;
        this.idConsulta = idConsulta;
        this.tipoNotificacao = tipoNot;
        this.textoNotificacao = txtNot;
        this.dataCriacao = dataCri;
        this.horaCriacao = dataHor;
        this.lida = lida;

    }

    public String getLida() {
        return lida;
    }

    public void setLida(String lida) {
        this.lida = lida;
    }

    public String getHoraCriacao() {
        return horaCriacao;
    }

    public void setHoraCriacao(String horaCriacao) {
        this.horaCriacao = horaCriacao;
    }

    public String getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(String dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public String getTextoNotificacao() {
        return textoNotificacao;
    }

    public void setTextoNotificacao(String textoNotificacao) {
        this.textoNotificacao = textoNotificacao;
    }

    public String getTipoNotificacao() {
        return tipoNotificacao;
    }

    public void setTipoNotificacao(String tipoNotificacao) {
        this.tipoNotificacao = tipoNotificacao;
    }

    public String getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(String idConsulta) {
        this.idConsulta = idConsulta;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getidNotificacao() {
        return idNotificacao;
    }

    public void setidNotificacao(String dNotificacao) {
        this.idNotificacao = dNotificacao;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }
}
