package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.internomodel.API.ApiService;
import com.example.internomodel.API.RetrofitClient;
import com.example.internomodel.API.classes.ClsDisponibilidade;
import com.example.internomodel.API.classes.ClsFuncionario;
import com.example.internomodel.API.classes.ClsLogin;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class agendamento extends AppCompatActivity {

    ClsLogin login;
    ApiService apiService;
    static int year, month;
    TextView lblMesAgendamento;
    String[] diasIndisponiveis = {"3.07f", "17.08f"};

    Button btnContinuar;

    EditText txtData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agendamento);


        btnContinuar = findViewById(R.id. btnContinuar);

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM");
        month = Integer.parseInt(dateFormat.format(Calendar.getInstance().getTime()));

        dateFormat = new SimpleDateFormat("yyyy");
        year = Integer.parseInt(dateFormat.format(Calendar.getInstance().getTime()));

        txtData = findViewById(R.id.txtData);

        lblMesAgendamento = findViewById(R.id.lblMesAgendamento);

        findViewById(R.id.imgX).setOnClickListener((v)->{
            finish();
        });
        //buildCalendar();

        btnContinuar.setOnClickListener(v->{
            Intent it = new Intent(getBaseContext(), MarcarAgendamento.class);
            startActivity(it);

        });




        findViewById(R.id.imgNextMonth).setOnClickListener((v)->{
            month++;
            if(month > 12){
                month = 1;
                year++;
            }
            buildCalendar();
        });

        findViewById(R.id.imgPreviousMonth).setOnClickListener((v)->{
            month--;
            if(month < 1){
                month = 12;
                year--;
            }
            buildCalendar();
        });

        inicializarDados();


    }

    private void inicializarDados(){
        login = new ClsLogin();
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);
        Call<List<ClsFuncionario>> call = apiService.getCnpjByIdFunc(login.getId());
        call.enqueue(new Callback<List<ClsFuncionario>>() {
            @Override
            public void onResponse(Call<List<ClsFuncionario>> call, Response<List<ClsFuncionario>> response) {
                getDatasIndisponiveis(response.body().get(0).getCnpj());
            }

            @Override
            public void onFailure(Call<List<ClsFuncionario>> call, Throwable t) {

            }
        });
        
    }


    private String tratarData(String data){
        String novaData = "";
        char chars[] = new char[10];
        for(int i = 0; i < 10; i ++){
            chars[i] = data.charAt(i);

        }
        novaData = chars[8]+""+chars[9]+"/"+chars[5]+""+chars[6];
        return novaData;
    }

    private String getAno(String data){
        String ano = "";
        for(int i = 0; i < 4;i++){
            ano += data.charAt(i);

        }
        return ano;
    }
    private void getDatasIndisponiveis(String cnpj){
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);
        Call<List<ClsDisponibilidade>> call = apiService.getDisponibilidadeByCnpj(cnpj);

        call.enqueue(new Callback<List<ClsDisponibilidade>>() {
            @Override
            public void onResponse(Call<List<ClsDisponibilidade>> call, Response<List<ClsDisponibilidade>> response) {
                List<ClsDisponibilidade> listaDatas = response.body();
                diasIndisponiveis = new String[listaDatas.size()];
                for(int i = 0; i < listaDatas.size();i++){
                    String e = listaDatas.get(i).getDataIndisponivel();
                    diasIndisponiveis[i] = tratarData(e)+"/"+getAno(e);
                    Log.e("Data Tratada", diasIndisponiveis[i]);
                }
                buildCalendar();
            }

            @Override
            public void onFailure(Call<List<ClsDisponibilidade>> call, Throwable t) {
                Log.e("ERRRRRRRRR", t+"");
            }
        });




    }





    int getDeterminateDate(int year, int month, int day) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                LocalDate a = LocalDate.of(year, month, day);
                int dayWeek = a.getDayOfWeek().getValue();
                return dayWeek;
            }
            return 0;
        }catch(Exception err){
            return -1;
        }
    }

    void clearBackground(boolean limparTudo){
        LinearLayout tabela =  findViewById(R.id.llDias);
        for(int i = 1; i < tabela.getChildCount(); i++) {
            LinearLayout semana = (LinearLayout) tabela.getChildAt(i);
            for (int j = 0; j < semana.getChildCount(); j++) {

                TextView dia = (TextView) semana.getChildAt(j);

                if(!(ColorStateList.valueOf(dia.getCurrentTextColor())== ColorStateList.valueOf(getColor(R.color.rosa))) || limparTudo){
                    dia.setBackgroundResource(0);
                    dia.setTextColor(ColorStateList.valueOf(getColor(R.color.white)));
                }


            }
        }
    }

    String dayName(int idWeek){
        String[] week = {"Domingo","Segunda-Feira","Terça-Feira","Quarta-Feira","Quinta-Feira","Sexta-Feira","Sábado"};
        return week[idWeek];
    }
    String monthName(int idMonth){
        String[] months = {"Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        return months[idMonth];
    }
    @SuppressLint("ResourceType")

    void buildCalendar(){
        clearBackground(true);
        LinearLayout tabela =  findViewById(R.id.llDias);
        lblMesAgendamento.setText(monthName(month-1));

        int numeroDia = 0;
        int diaSemana = getDeterminateDate(year,month,1)%7;
        int ultimoDia = 31;



        while (getDeterminateDate(year, month, ultimoDia) == -1) {
            ultimoDia--;
        }

        for(int i = 1; i < tabela.getChildCount(); i++){
            LinearLayout semana = (LinearLayout) tabela.getChildAt(i);
            for(int j = 0; j < semana.getChildCount(); j++){
                TextView lblDia = (TextView) semana.getChildAt(j);
                lblDia.setWidth((int)Math.floor(semana.getWidth()/7));
                lblDia.setHeight((int)Math.floor(semana.getWidth()/7));

                if(((diaSemana > j) && (i < 2))||(numeroDia >= ultimoDia)){
                    lblDia.setText("");
                    lblDia.setOnClickListener(null);

                }else{
                    numeroDia++;
                    lblDia.setText(numeroDia+"");

                    if(numeroDia == 1) {
                        lblDia.setBackgroundResource(R.drawable._round);
                        lblDia.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.verificar)));
                        int idDayWeek = (int) ((Integer.parseInt(lblDia.getText().toString()) % 7 ) +diaSemana-1) %7;
                        txtData.setText(dayName(idDayWeek)+", "+year);
                    }


                    boolean estaIndisponivel = false;
                    //VERIFICAR SE O DIA É INDISPONIVEL

                    for(int a = 0;a<diasIndisponiveis.length;a++){

                        String data = diasIndisponiveis[a];


                        System.out.println("data comp: "+data);
                        System.out.println(" ano: "+year);
                        System.out.println(" | mes data: "+data.charAt(3)+""+data.charAt(4));
                        System.out.println(" | mês codigo: "+month);
                        System.out.println(" | dia data: "+(data.charAt(0)+""+data.charAt(1)));
                        System.out.println(" | dia código: "+numeroDia);


                        if(  (data.contains(year+"")) && (Integer.parseInt(data.charAt(3)+""+data.charAt(4)) == (month)) && (Integer.parseInt(data.charAt(0)+""+data.charAt(1)) == numeroDia)  ){
                            lblDia.setBackgroundResource(R.drawable._round);
                            lblDia.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.white)));
                            lblDia.setTextColor(ColorStateList.valueOf(getColor(R.color.rosa)));
                            estaIndisponivel = true;   lblDia.setOnClickListener(null);

                            break;
                        }
                    }


/*
                    for(int k = 0; k < diasIndisponiveis.length;k++){
                        float e = diasIndisponiveis[k];
                        if((e*100-Math.floor(e)*100)-month == 0 && Math.floor(e) == numeroDia){
                            lblDia.setBackgroundResource(R.drawable._round);
                            lblDia.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.white)));
                            lblDia.setTextColor(ColorStateList.valueOf(getColor(R.color.rosa)));
                            estaIndisponivel = true;   lblDia.setOnClickListener(null);

                            break;
                        }

                    }*/



                    //

                    if(!estaIndisponivel) {
                        lblDia.setOnClickListener((v) -> {
                            clearBackground(false);

                            lblDia.setBackgroundResource(R.drawable._round);
                            lblDia.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.verificar)));

                            int idDayWeek = (int) ((Integer.parseInt(lblDia.getText().toString()) % 7) + diaSemana - 1) % 7;
                            txtData.setText(dayName(idDayWeek) + ", " + year);
                        });
                    }



                }
            }
        }
    }
}