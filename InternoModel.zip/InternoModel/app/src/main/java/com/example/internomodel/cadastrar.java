package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;


import com.example.internomodel.API.RetrofitClient;
import com.example.internomodel.API.ApiService;
import com.example.internomodel.API.classes.ClsHospital;
import com.example.internomodel.API.classes.ClsUsuario;
import com.example.internomodel.API.classes.*;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class cadastrar extends AppCompatActivity {

    TextView lblCpf, lblNome,lblAssociacao;
    EditText txtCpf, txtNome, txtConfirmarSenha;
    static String[] hospitaisAssociacao = new String[0];
    static String[] CnpjHospital = new String[0];
    ApiService apiservice;

    ImageView imgSenhaHid, imgConfirmSenhaHid;

    ConstraintLayout clCadastro;
    Spinner spinner;


    String nomeF, cpfF, assoc, cnpjF, idF, email, senha;


    LinearLayout llvNome, llvAssociacao, llvCadastro;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);

        clCadastro = findViewById(R.id.clCadastro);

        txtConfirmarSenha = findViewById(R.id.txtConfirmarSenha);
        txtNome = findViewById(R.id.txtNome);
        txtCpf = findViewById(R.id.txtCpf);

        lblCpf = findViewById(R.id.lblCpf);
        lblNome = findViewById(R.id.lblNome);
        lblAssociacao = findViewById(R.id.lblAssociacao);

        llvNome = findViewById(R.id.llVNome);
        llvAssociacao = findViewById(R.id.llvAssociacao);
        llvCadastro = findViewById(R.id.llvCadastro);

        imgSenhaHid = findViewById(R.id.imgSenhaHid);
        imgConfirmSenhaHid = findViewById(R.id.imgConfirmSenhaHid);

        spinner = findViewById(R.id.spinner);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), CnpjHospital[position]+" : "+spinner.getSelectedItem().toString().toUpperCase(), Toast.LENGTH_SHORT).show();
                cnpjF = CnpjHospital[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        TextView lblVoltarLogin = (TextView) findViewById(R.id.lblVoltarLogin);

        lblVoltarLogin.setOnClickListener((v)->{
            Intent it = new Intent(getBaseContext(), MainActivity.class);
            startActivity(it);
            finish();

        });


        Button btnContinuar = (Button) findViewById(R.id.btnContinuar);

        llvCadastro.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float yInicial = 0;
                switch(event.getActionMasked()){

                    case MotionEvent.ACTION_DOWN:
                        yInicial = event.getY();

                        break;
                    case MotionEvent.ACTION_MOVE:
                        float yDesloc = event.getY() - yInicial;
                        float posicao = (llvCadastro.getTranslationY() +yDesloc> llvCadastro.getHeight()*0.75)?
                                llvCadastro.getHeight()*0.75f
                                :
                                (llvCadastro.getTranslationY() +yDesloc< 0)?0f:
                                        (llvCadastro.getTranslationY()+yDesloc);

                        llvCadastro.setTranslationY(posicao);
                        break;
                }
                return true;
            }
        });




        btnContinuar.setOnClickListener((v)->{
            if(!btnContinuar.getText().equals("Cadastrar")) {
                if(txtCpf.getText().toString().equals("") || txtNome.getText().toString().equals("")){
                    Toast.makeText(getBaseContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                    return;
                }
                lblCpf.setText("E-mail");
                lblNome.setText("Senha");
                lblAssociacao.setText("Confirmar senha");

                txtCpf.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
                txtCpf.setHint("Email@gmail.com");
                cpfF = txtCpf.getText().toString();
                txtCpf.setText("");
                txtCpf.setFilters(new InputFilter[]{new InputFilter.LengthFilter(50)});
                LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) llvNome.getLayoutParams();
                params.width = (int) (300 * getResources().getDisplayMetrics().density);


                imgSenhaHid.setVisibility(View.VISIBLE);
                imgConfirmSenhaHid.setVisibility(View.VISIBLE);

                txtNome.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                txtNome.setHint("Senha");
                nomeF = txtNome.getText().toString();
                txtNome.setText("");
                params = (LinearLayout.LayoutParams) llvAssociacao.getLayoutParams();
                params.width = (int) (300 * getResources().getDisplayMetrics().density);

                spinner.setVisibility(View.INVISIBLE);


                ViewGroup.LayoutParams param = txtConfirmarSenha.getLayoutParams();

                param.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                txtConfirmarSenha.setLayoutParams(param);
                txtConfirmarSenha.setVisibility(View.VISIBLE);
                txtConfirmarSenha.setHint("Confirmar senha");

                btnContinuar.setText("Cadastrar");
            }else{
                if(txtCpf.getText().toString().equals("") || !txtNome.getText().toString().equals(txtConfirmarSenha.getText().toString()) || txtNome.getText().toString().equals("")){
                    Toast.makeText(getBaseContext(),
                            (!txtNome.getText().toString().equals(txtConfirmarSenha.getText().toString()))?
                                    "Senhas não compativeis":
                                    "Preencha todos os campos"
                            , Toast.LENGTH_SHORT).show();
                    return;
                }
                email = txtCpf.getText().toString();
                senha = txtConfirmarSenha.getText().toString();

                cadastrar2();
            }

        });

        imgSenhaHid.setOnClickListener((v)->{
            boolean verification = (txtNome.getInputType() == InputType.TYPE_CLASS_TEXT);
            txtNome.setInputType(verification?(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD):InputType.TYPE_CLASS_TEXT);
            imgSenhaHid.setImageResource(verification?R.drawable.naovisivel_icon: R.drawable.visivelolho_icon);


        });





        imgConfirmSenhaHid.setOnClickListener((v)->{
            boolean verification = (txtConfirmarSenha.getInputType() == InputType.TYPE_CLASS_TEXT);
            txtConfirmarSenha.setInputType(verification?(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD):InputType.TYPE_CLASS_TEXT);
            imgConfirmSenhaHid.setImageResource(verification?R.drawable.naovisivel_icon:R.drawable.visivelolho_icon);

        });

        getHospitais();
    }

    private void getHospitais(){
        apiservice = RetrofitClient.getRetrofit().create(ApiService.class);
        Call<List<ClsHospital>> call = apiservice.getHospital();
        call.enqueue(new Callback<List<ClsHospital>>() {
            @Override
            public void onResponse(Call<List<ClsHospital>> call, Response<List<ClsHospital>> response) {
                lblCpf.setText(response.body().get(0).getCnpj());
                CnpjHospital = new String[response.body().size()];
                hospitaisAssociacao = new String[response.body().size()];
                for(int i = 0; i < response.body().size();i++){
                    CnpjHospital[i] = response.body().get(i).getCnpj();
                    hospitaisAssociacao[i] = response.body().get(i).getNomeHosp();
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_spinner_item, hospitaisAssociacao);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
            }
            @Override
            public void onFailure(Call<List<ClsHospital>> call, Throwable t) {
            }
        });
    }

    private void cadastrar2(){

        apiservice = RetrofitClient.getRetrofit().create(ApiService.class);
        Call<List<ClsUsuario>> call = apiservice.getVerificarUsuario(email, senha);
        call.enqueue(new Callback<List<ClsUsuario>>() {
            @Override
            public void onResponse(Call<List<ClsUsuario>> call1, Response<List<ClsUsuario>> response1) {
                List<ClsUsuario> a =  response1.body();

                if(a.size() == 0){

                    ClsCadastrarD data = new ClsCadastrarD(email, senha, nomeF, cpfF, cnpjF);
                    Call<ClsCadastrarD> call2 = apiservice.cadastrar2(data);
                    call2.enqueue(new Callback<ClsCadastrarD>() {
                        @Override
                        public void onResponse(Call<ClsCadastrarD> call, Response<ClsCadastrarD> response) {
                        }
                        @Override
                        public void onFailure(Call<ClsCadastrarD> call, Throwable t) {

                        }
                    });
                    Intent it = new Intent(getBaseContext(), MainActivity.class);
                    startActivity(it);
                    Toast.makeText(getBaseContext(), "Usuário Cadastrado", Toast.LENGTH_SHORT).show();
                    finish();

                }else{
                    Toast.makeText(getBaseContext(), "Esse usuário já¡ está¡ cadastrado!", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<List<ClsUsuario>> call1, Throwable t) {
                Log.e("ERRO", t.getMessage().toString());
            }
        });
    }
}
