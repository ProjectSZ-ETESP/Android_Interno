package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class confirmarAgendamento extends AppCompatActivity {

    ImageView imgVoltar;
    Button btnAgendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_agendamento);

        imgVoltar = findViewById(R.id.imgVoltar);
        btnAgendar = findViewById(R.id.btnAgendar);

        imgVoltar.setOnClickListener(v->{
            finish();
        });

        btnAgendar.setOnClickListener(v->{
            Toast.makeText(getBaseContext(),"Agendado!",Toast.LENGTH_SHORT).show();
        });


    }
}