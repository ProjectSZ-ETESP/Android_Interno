package com.example.internomodel.API.classes;

import com.google.gson.annotations.SerializedName;

public class ClsMedico {

    @SerializedName("crm")
    private String crm;
    @SerializedName("cnpj")
    private String cnpj;
    @SerializedName("nomeMedico")
    private String nomeMedico;
    @SerializedName("tipoMedico")
    private String tipoMedico;
    @SerializedName("emailMedico")
    private String emailMedico;
    @SerializedName("sexoMedico")
    private String sexoMedico;
    @SerializedName("dataNascMedico")
    private String dataNascMedico;
    @SerializedName("foneMedico")
    private String foneMedico;


    public ClsMedico(String crm, String cnpj, String nomeMedico, String tipoMedico, String emailMedico,
                  String sexoMedico, String dataNascMedico, String foneMedico) {
        this.crm = crm;
        this.cnpj = cnpj;
        this.nomeMedico = nomeMedico;
        this.tipoMedico = tipoMedico;
        this.emailMedico = emailMedico;
        this.sexoMedico = sexoMedico;
        this.dataNascMedico = dataNascMedico;
        this.foneMedico = foneMedico;
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNomeMedico() {
        return nomeMedico;
    }

    public void setNomeMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }

    public String getTipoMedico() {
        return tipoMedico;
    }

    public void setTipoMedico(String tipoMedico) {
        this.tipoMedico = tipoMedico;
    }

    public String getEmailMedico() {
        return emailMedico;
    }

    public void setEmailMedico(String emailMedico) {
        this.emailMedico = emailMedico;
    }

    public String getSexoMedico() {
        return sexoMedico;
    }

    public void setSexoMedico(String sexoMedico) {
        this.sexoMedico = sexoMedico;
    }

    public String getDataNascMedico() {
        return dataNascMedico;
    }

    public void setDataNascMedico(String dataNascMedico) {
        this.dataNascMedico = dataNascMedico;
    }

    public String getFoneMedico() {
        return foneMedico;
    }

    public void setFoneMedico(String foneMedico) {
        this.foneMedico = foneMedico;
    }
}
