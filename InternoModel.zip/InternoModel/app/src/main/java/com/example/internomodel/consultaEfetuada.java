package com.example.internomodel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.internomodel.API.ApiService;
import com.example.internomodel.API.RetrofitClient;
import com.example.internomodel.API.classes.ClsConsulta;
import com.example.internomodel.API.classes.ClsLogin;
import com.example.internomodel.API.classes.ClsMedico;
import com.example.internomodel.API.classes.ClsPaciente;
import com.example.internomodel.API.classes.ClsProntuario;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class consultaEfetuada extends AppCompatActivity {
    ImageView imgBack;
    ApiService apiService;
    TextView lblId, lblData, lblHora, lblNome, lblDoutor, lblTipo, lblDescricao;
    ClsLogin login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_efetuada);
        login = new ClsLogin();

        imgBack = findViewById(R.id.imgBack);
        imgBack.setOnClickListener(v->{finish();});
        lblId = findViewById(R.id.lblId);
        lblData = findViewById(R.id.lblData);
        lblHora = findViewById(R.id.lblHora);
        lblNome= findViewById(R.id.lblNome);
        lblDoutor= findViewById(R.id.lblDoutor);
        lblTipo= findViewById(R.id.lblTipo);
        lblDescricao = findViewById(R.id.lblDescricao);

        getDadosConsulta(login.getIdConsultaForH());


    }

    private String getAno(String data){
        String ano = "";
        for(int i = 0; i < 4;i++){
            ano += data.charAt(i);

        }
        return ano;
    }
    private String tratarData(String data){
        String novaData = "";
        char chars[] = new char[10];
        for(int i = 0; i < 10; i ++){
            chars[i] = data.charAt(i);

        }
        novaData = chars[8]+""+chars[9]+"/"+chars[5]+""+chars[6];
        return novaData;
    }

    private void getDadosConsulta(String idConsultaLog){
        apiService = RetrofitClient.getRetrofit().create(ApiService.class);

        Call<List<ClsConsulta>> call = apiService.getConsulta(idConsultaLog);

        call.enqueue(new Callback<List<ClsConsulta>>() {
            @Override
            public void onResponse(Call<List<ClsConsulta>> call, Response<List<ClsConsulta>> response) {
                ClsConsulta consulta = response.body().get(0);

                lblData.setText(tratarData(consulta.getDataConsulta())+"/"+getAno(consulta.getDataConsulta()));
                lblHora.setText(consulta.getHoraConsulta());
                lblId.setText(consulta.getIdPaciente());
                lblTipo.setText(consulta.getTipoConsulta());

                Call<List<ClsPaciente>> call1 = apiService.getPaciente(consulta.getIdPaciente());
                call1.enqueue(new Callback<List<ClsPaciente>>() {
                    @Override
                    public void onResponse(Call<List<ClsPaciente>> call, Response<List<ClsPaciente>> response) {
                        lblNome.setText(response.body().get(0).getNomePaciente());

                    }

                    @Override
                    public void onFailure(Call<List<ClsPaciente>> call, Throwable t) {

                    }
                });
                Call<List<ClsProntuario>> call2 = apiService.getProntuario(consulta.getIdConsulta());
                call2.enqueue(new Callback<List<ClsProntuario>>() {
                    @Override
                    public void onResponse(Call<List<ClsProntuario>> call, Response<List<ClsProntuario>> response) {
                        lblDescricao.setText(response.body().get(0).getDescricao());
                    }

                    @Override
                    public void onFailure(Call<List<ClsProntuario>> call, Throwable t) {

                    }
                });
/**/
                Call<List<ClsMedico>> call3 = apiService.getMedicoById(consulta.getCrm());
                call3.enqueue(new Callback<List<ClsMedico>>() {
                    @Override
                    public void onResponse(Call<List<ClsMedico>> call, Response<List<ClsMedico>> response) {
                        lblDoutor.setText(response.body().get(0).getNomeMedico());
                    }

                    @Override
                    public void onFailure(Call<List<ClsMedico>> call, Throwable t) {

                    }
                });
/**/

            }

            @Override
            public void onFailure(Call<List<ClsConsulta>> call, Throwable t) {

            }
        });



    }
}