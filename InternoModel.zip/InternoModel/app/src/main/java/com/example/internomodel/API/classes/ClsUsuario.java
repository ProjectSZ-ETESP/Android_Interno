package com.example.internomodel.API.classes;
import com.google.gson.annotations.SerializedName;
public class ClsUsuario {
    @SerializedName("idUsuario")
    private int idUsuario;
    @SerializedName("email")
    private String email;
    @SerializedName("senha")
    private String senha;

    public ClsUsuario( String email, String senha){
        this.email = email;
        this.senha = senha;
    }


    public int get_idUsuario() {
        return this.idUsuario;
    }

    public void set_idUsuario(int _id) {
        this.idUsuario = _id;
    }

    public String get_email() {
        return this.email;
    }

    public void set_email(String _email) {
        this.email = _email;
    }

    public  String get_senha() {
        return this.senha;
    }

    public void set_senha(String _senha) {
        this.senha = _senha;
    }
}
