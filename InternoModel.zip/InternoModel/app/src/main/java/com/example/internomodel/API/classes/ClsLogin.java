package com.example.internomodel.API.classes;

public class ClsLogin {
    private static String id;
    private static String email;
    private static String senha;

    private static String idConsultaForH;

    public String getIdConsultaForH() {
        return idConsultaForH;
    }

    public void setIdConsultaForH(String idConsultaForH) {
        ClsLogin.idConsultaForH = idConsultaForH;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        ClsLogin.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        ClsLogin.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        ClsLogin.senha = senha;
    }



}
