package com.example.internomodel.API.classes;

import com.google.gson.annotations.SerializedName;

public class ClsProntuario {
    @SerializedName("idProntuario")
    private String idProntuario;
    @SerializedName("idConsulta")
    private String idConsulta;
    @SerializedName("tipoConsulta")
    private String tipoConsulta;
    @SerializedName("descricao")
    private String descricao;
    @SerializedName("receituario")
    private String receituario;



    public ClsProntuario(String idPront, String idCon, String tipoCon, String desc, String receit){
        this.idProntuario = idPront;
        this.idConsulta = idCon;
        this.tipoConsulta = tipoCon;
        this.descricao = desc;
        this.receituario = receit;
    }




    public String getReceituario() {
        return receituario;
    }

    public void setReceituario(String receituario) {
        this.receituario = receituario;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipoConsulta() {
        return tipoConsulta;
    }

    public void setTipoConsulta(String tipoConsulta) {
        this.tipoConsulta = tipoConsulta;
    }

    public String getIdProntuario() {
        return idProntuario;
    }

    public void setIdProntuario(String idProntuario) {
        this.idProntuario = idProntuario;
    }

    public String getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(String idConsulta) {
        this.idConsulta = idConsulta;
    }
}
